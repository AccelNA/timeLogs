var React = require('react');
var DateRangePicker = require('react-bootstrap-daterangepicker');
var moment = require('moment');
var RB = require('react-bootstrap');
var Rows = require('./Row');

var DashboardMain = React.createClass({

	
   render:function(){
   	return (<div></div>);
   }   
	
});


React.render(<DashboardMain />,document.body);

module.exports = DashboardMain;
