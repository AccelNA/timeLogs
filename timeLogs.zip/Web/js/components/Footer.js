/**
 * Footer
 */

var React = require('react');
var ReactPropTypes = React.PropTypes;

var Footer = React.createClass({

  render: function() {
    return (
	     <footer>
			<p>Powered by <a href="">Accel FrontLine,Cochin</a></p>
		 </footer>
    );
  }

});

module.exports = Footer;
