ConfigComp = {
     serverUrl  : 'http://localhost/JREAM/',
     clientBaseUrl : 'http://localhost/JREAM/AccelHRTime/TimeTracker/src/TimeTracker.web/index.html#/',
     ROLE_ADMIN :'ADMIN',
     ROLE_USER  :'USER',
     ROLE_GUEST :'GUEST',
     secretKey : 'AnySecretKeyyouCan@Use'
}

module.exports = ConfigComp;