/*
 * 
 * TaskConstants
 */

var keyMirror = require('keymirror');

module.exports = keyMirror({
  TASK_CREATE: null,
  TASK_LIST: null,
  TASK_DELETE: null,
  TASK_EDIT:null
});
