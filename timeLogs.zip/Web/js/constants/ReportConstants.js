/*
 * 
 * TaskConstants
 */

var keyMirror = require('keymirror');

module.exports = keyMirror({
  REPORT_LIST: null,
  REPORT_TASK_LIST:null
});
