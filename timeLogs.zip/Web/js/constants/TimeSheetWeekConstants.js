/*
 * 
 * TaskConstants
 */

var keyMirror = require('keymirror');

module.exports = keyMirror({
  TIMESHEETWEEKSTORE_CREATE: null
});
