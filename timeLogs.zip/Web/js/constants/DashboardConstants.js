/*
 * 
 * TaskConstants
 */

var keyMirror = require('keymirror');

module.exports = keyMirror({
  ADDMOREROW: null
});
