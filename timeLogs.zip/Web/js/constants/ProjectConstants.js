/*
 * 
 * TaskConstants
 */

var keyMirror = require('keymirror');

module.exports = keyMirror({
  PROJECT_CREATE: null,
  PROJECT_DESTROY: null,
  PROJECT_DELETE:null,
  PROJECT_EDIT:null
});
