/*
 * 
 * TaskConstants
 */

var keyMirror = require('keymirror');

module.exports = keyMirror({
  USER_CREATE: null,
  USER_LIST: null,
  USER_DELETE:null,
  USER_EDIT:null
});
