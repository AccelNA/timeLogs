/*
 * 
 * TaskConstants
 */

var keyMirror = require('keymirror');

module.exports = keyMirror({
  TIMESHEETDAYSTORE_CREATE: null,
  TIMESHEETDAYSTORE_LIST: null,
  TIMESHEETDAYSTORE_DELETE:null 
});
