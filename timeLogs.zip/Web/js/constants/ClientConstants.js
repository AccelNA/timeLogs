/*
 * 
 * TaskConstants
 */

var keyMirror = require('keymirror');

module.exports = keyMirror({
  CLIENT_CREATE: null,
  CLIENT_LIST: null,
  CLIENT_DELETE:null,
  CLIENT_EDIT:null
});
